rows = 5
for i in range(rows, 0, -1):
#     print('*' * i)
    print(' ' * (rows - i) + '*' * i) 