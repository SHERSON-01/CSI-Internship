rows = 5  # You can change this value for a larger or smaller triangle

for i in range(1, rows + 1):
    print('*' * i)
    